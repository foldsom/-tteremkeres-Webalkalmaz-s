import React from 'react';

function App() {
  return (
    <div>
      <h1>Étteremkereső Projekt</h1>
      <p>Sikerült a React telepítése!</p>
    </div>
  );
}

export default App;